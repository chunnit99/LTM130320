package com.example1.crud.controller;

import com.example1.crud.entity.Student;
import com.example1.crud.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class StudentController {
    @Autowired private StudentService studentService;


    @GetMapping(value = "/students")
    public ResponseEntity<List<Student>> getAllStudent(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin", "*");
        List<Student> students = studentService.getAllStudent();
        if (students.isEmpty()){
            return  new ResponseEntity<>(students, HttpStatus.NO_CONTENT);
        }
        return  new ResponseEntity<>(students, HttpStatus.OK);
    }

    @GetMapping(value = "/students/{id}")
    public ResponseEntity<Student> getProductById(
            @PathVariable("id") Integer id) {
        Optional<Student> student = studentService.findStudentById(id);

        if (!student.isPresent()) {
            return new ResponseEntity<>(student.get(),
                    HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(student.get(), HttpStatus.OK);
    }

    @PostMapping(value = "/add-student")
    public ResponseEntity<Student> createStudent(
            @RequestBody Student student,
            UriComponentsBuilder builder) {
        studentService.saveStudent(student);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(builder.path("/students/{id}")
                .buildAndExpand(student.getId()).toUri());
        return new ResponseEntity<>(student, HttpStatus.CREATED);
    }

    @PutMapping(value = "/update-student/{id}")
    public ResponseEntity<List<Student>> updateStudent(
            @PathVariable("id") Integer id,
            @RequestBody Student student) {
        Optional<Student> currentStudent = studentService.findStudentById(id);

        if (!currentStudent.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        currentStudent.get().setName(student.getName());
        currentStudent.get().setAddress(student.getAddress());
        currentStudent.get().setBirthday(student.getBirthday());

        studentService.saveStudent(currentStudent.get());
        List<Student> students = studentService.getAllStudent();
        return new ResponseEntity<>(students, HttpStatus.OK);
    }

    @DeleteMapping(value = "/delete-student/{id}")
    public ResponseEntity<List<Student>> deleteStudent(
            @PathVariable("id") Integer id) {
        Optional<Student> product = studentService.findStudentById(id);
        if (!product.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        studentService.deleteStudent(id);
        List<Student> students = studentService.getAllStudent();
        return new ResponseEntity<>(students, HttpStatus.OK);
    }
}
